"""Fake Anthropic Messages endpoint for FB-105 evidence.

Main model `keeps-it`: first answer is an Agent tool call to subagent_type
`third-model`; afterwards a plain text reply.
Model `third-model`: mimics an upstream that refuses system-role messages in
the middle of the conversation (HTTP 400 "System messages are not allowed")
whenever the request carries any message whose role is "system" or a
<system-reminder> text block placed as a system message. Every request body
is logged to LOG for inspection."""
import json, sys, http.server, itertools
LOG = sys.argv[2]
counter = itertools.count()

def sse(events):
    out = b""
    for name, data in events:
        out += f"event: {name}\ndata: {json.dumps(data)}\n\n".encode()
    return out

def text_reply(model, text):
    return sse([
        ("message_start", {"type": "message_start", "message": {"id": "m", "type": "message", "role": "assistant", "model": model, "content": [], "stop_reason": None, "usage": {"input_tokens": 1, "output_tokens": 1}}}),
        ("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}}),
        ("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": text}}),
        ("content_block_stop", {"type": "content_block_stop", "index": 0}),
        ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 1}}),
        ("message_stop", {"type": "message_stop"}),
    ])

def tool_reply(model):
    inp = json.dumps({"description": "probe", "prompt": "Say OK.", "subagent_type": "third-model"})
    return sse([
        ("message_start", {"type": "message_start", "message": {"id": "m", "type": "message", "role": "assistant", "model": model, "content": [], "stop_reason": None, "usage": {"input_tokens": 1, "output_tokens": 1}}}),
        ("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {"type": "tool_use", "id": "toolu_1", "name": "Agent", "input": {}}}),
        ("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "input_json_delta", "partial_json": inp}}),
        ("content_block_stop", {"type": "content_block_stop", "index": 0}),
        ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "tool_use"}, "usage": {"output_tokens": 1}}),
        ("message_stop", {"type": "message_stop"}),
    ])

class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        self.send_response(200); self.send_header("content-type", "application/json"); self.end_headers(); self.wfile.write(b'{"data":[]}')
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))) or b"{}")
        if not self.path.startswith("/v1/messages") or self.path.startswith("/v1/messages/count_tokens"):
            self.send_response(200); self.send_header("content-type", "application/json"); self.end_headers(); self.wfile.write(b'{"input_tokens":1}'); return
        model = body.get("model", "")
        msgs = body.get("messages", [])
        system_roles = [i for i, m in enumerate(msgs) if m.get("role") == "system"]
        n = next(counter)
        entry = {"n": n, "model": model, "roles": [m.get("role") for m in msgs], "system_role_at": system_roles}
        if model == "third-model" and system_roles:
            entry["status"] = 400
            with open(LOG, "a") as f: f.write(json.dumps(entry) + "\n")
            payload = json.dumps({"type": "error", "error": {"type": "invalid_request_error", "message": "System messages are not allowed"}}).encode()
            self.send_response(400); self.send_header("content-type", "application/json"); self.send_header("content-length", str(len(payload))); self.end_headers(); self.wfile.write(payload); return
        if model == "third-model":
            out = text_reply(model, "OK from third-model")
        elif any(isinstance(m.get("content"), list) and any(b.get("type") == "tool_result" for b in m["content"]) for m in msgs if m.get("role") == "user"):
            out = text_reply(model, "done")
        elif body.get("tools"):
            out = tool_reply(model)
        else:
            out = text_reply(model, "ok")
        entry["status"] = 200
        with open(LOG, "a") as f: f.write(json.dumps(entry) + "\n")
        self.send_response(200); self.send_header("content-type", "text/event-stream"); self.end_headers(); self.wfile.write(out)

http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
