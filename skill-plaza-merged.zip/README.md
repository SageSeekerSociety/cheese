# skill-plaza-merged —— PR #3167 的合并结果

`fate-trojan/cheese` 的 `feat/skill-plaza` 与 `SageSeekerSociety/cheese` 的 `main` 合并、
解掉 14 个冲突之后的结果。

- 合并提交：`aa740428950f142a3e30ac4e13107374a82a306e`
- 首个父提交：`3c523452e311244f6fe2545de3b316fe06669cc2`（`feat/skill-plaza` 当前的尖端）
- 第二个父提交：`f6edbad92fb3d2861d34cda72980d5f6172e782f`（`main` 当前的尖端，2026-10-14 取的）
- 合并基点：`48db3215f94d199189c2cfa2526242940833a134`

首个父提交是分支尖端，所以这个提交可以直接快进推到 `feat/skill-plaza`，**不需要 `--force`**。

包里两样东西，任选一条路：

| 文件 | 用途 |
| --- | --- |
| `skill-plaza-merged.bundle` | 首选。git bundle，快进推送，保留合并的亲子关系 |
| `skill-plaza-merged.patch` | 退路。bundle 用不了时，把它打到分支尖端上 |

## 前提

本地那份克隆里要有**分支尖端 `3c523452`**（就是你 fork 上 `feat/skill-plaza` 现在指向的提交）。

bundle 还引用 `48db3215`，那是 `3c523452` 的祖先，有 `3c523452` 就一定有它，不用另外取。

## 第一条路：bundle（推荐）

```sh
git fetch /path/to/skill-plaza-merged.bundle \
  refs/heads/pr3167-merge:refs/heads/skill-plaza-merged

git log --oneline -1 skill-plaza-merged        # 应该是 aa740428
git rev-list --parents -n1 skill-plaza-merged  # 确认父提交是 3c523452 和 f6edbad9

git push origin skill-plaza-merged:feat/skill-plaza
```

快进推送，不带 `--force`。推完 #3167 会自动重新跑 CI（原来那个「CI 红」是冲突挂住了 workflow，
不是哪条用例失败）。

## 第二条路：patch（bundle 走不通时）

在分支尖端上打这个补丁，得到和合并结果一样的**树**（只是一条普通提交，没有合并的亲子关系）。

```sh
git switch feat/skill-plaza
git status                       # 先确认工作区干净
git apply --3way skill-plaza-merged.patch
# 若有冲突，解掉；然后在工作区里核对一遍
git add -A
git commit -m "merge main into feat/skill-plaza"
git push origin feat/skill-plaza
```

补丁是 `git diff 3c523452 aa740428`（带 `--binary`），所以它同时包含 main 侧（基点
`48db3215` 之后的 56 个提交）带来的改动和冲突的解，共 495 个文件。

## 冲突是怎么解的

口径按你定的：同一处两边都改、意思相反时**取 main 那一版**（main 的改动都来自编号更大的 PR）。

有一处没有机械照抄：`backend/app/api/awaiting_deps.py` 的「在等谁」那一块，main 的写法引用了
分支里不存在的变量（main 用 `asked[x].waiting()`，分支用一卡多评审人的
`reviewer_handles_for_cards`）。那里保留了分支的查询结构，只取 main 的语义。

分支自己的特性都留着：退休 `accept_card_reviewer` 列、改成一卡多评审人的表；
`.importlinter` 里分支新增的 `machine_skill : skill_market` 一层；
`frontend/src/i18n/messages/*/apiError.json` 里分支新加的键。

14 个冲突文件：

```
backend/.importlinter
backend/alembic/HEAD
backend/app/api/awaiting_deps.py
backend/app/api/room_task_rows.py
backend/app/api/routes/spaces.py
backend/app/api/routes/spaces_organization.py
backend/app/api/routes/tasks/roster.py
backend/scripts/route_index.json
backend/tests/integration/test_own_claude_code_teammate.py
backend/tests/unit/test_route_index_boundaries.py
frontend/a11y-baseline.json
frontend/src/i18n/messages/en/apiError.json
frontend/src/i18n/messages/zh-CN/apiError.json
frontend/src/views/tasks/Edit.vue
```

派生文件是照仓库自己的生成器**重新生成**的，不是手工合出来的：

- `backend/alembic/HEAD` 哨兵 + 分支的迁移链重接到 main 的新 head `6ac10b7f1b11` 上
  （`uv run alembic heads` 只剩一个；`.claude/scripts/check-migration-fork.py` PASS）
- `backend/scripts/route_index.json` 用 `scripts/route_index.py --emit` 重跑
- `backend/openapi.json`、`backend/openapi-untyped.json` 用 `scripts.export_openapi` 重跑
  （`--check` 通过）

## 验过什么、没验什么

在这台机器上验过：

- `ruff check` / `ruff format --check` 通过
- 模块边界（import-linter + 冻结基线）9 个契约 KEPT
- 延迟导入基线、仓库规则检查通过
- 迁移分叉检查 PASS、迁移安全检查 PASS（分支那条 `b1a2c3d4e5f6` 有一条
  `alter-column-existing` 警告，是它本来就有的）
- `backend/tests/unit/test_route_index.py`、`test_route_index_boundaries.py`：58 passed
- 解冲突后的 `frontend/src/views/tasks/Edit.vue` 能被 Vue 编译器解析、脚本能编译

**没在这台机器上跑**（交给 CI）：

- 集成测试和后端全量测试：这台机器上没有 Postgres/Redis，起不来
- `pyright`：被内存上限杀掉（JavaScript heap out of memory），没跑成
- 前端构建、类型检查、eslint：没在本地跑

所以递卡时没有声称 CI 会是绿的，只看 CI 的结果。
