# skill-plaza-merged — PR #3167 的合并结果

`fate-trojan/cheese` 的 `feat/skill-plaza` 与 `SageSeekerSociety/cheese` 的 `main` 合并、
解掉冲突之后的结果。

- 合并提交：`c69c7cde32e10357c1ae18820e238dc4d6c01c82`
- 首个父提交：`a554f5854319c1256a9c033b741ad37112e38dda`（`feat/skill-plaza` 的尖端）
- 第二个父提交：`966620e2cc6c4ec091e8ad6f35b9022e903c6d09`（`main`）
- 合并基点：`2657b707642a81d46463ecc06425d85267a6e3c0`
- 合入的 main 是当时的最新：`966620e2c`（`fix(chat): unify the bookmark glyph…` #4715）

首个父提交是分支尖端，所以这个提交可以直接快进推到 `feat/skill-plaza`，**不需要 `--force`**。

| 文件 | 用途 |
| --- | --- |
| `skill-plaza-merged.bundle` | 首选。git bundle，快进推送，保留合并的亲子关系 |
| `skill-plaza-merged.patch` | 退路。bundle 用不了时，把它打到分支尖端上 |

## 前提

本地那份克隆里要有**分支尖端 `a554f5854`**（fork 上 `feat/skill-plaza` 现在指向的提交）。

## 第一条路：bundle（推荐）

```sh
git fetch /path/to/skill-plaza-merged.bundle \
  refs/heads/pr3167-merge:refs/heads/skill-plaza-merged
git log --oneline -1 skill-plaza-merged
git rev-list --parents -n1 skill-plaza-merged   # 确认父提交
git push origin skill-plaza-merged:feat/skill-plaza
```

## 第二条路：patch（bundle 走不通时）

```sh
git switch feat/skill-plaza
git status
git apply --3way skill-plaza-merged.patch
git add -A
git commit -m "merge main into feat/skill-plaza"
git push origin feat/skill-plaza
```

# 结构性冲突的处置

| 文件 | 处置 | 依据 |
|---|---|---|
| `backend/.importlinter` | 取 main 的四层 + 补分支的 `machine_skill` / `skill_market` | 核过 104 个 domain 模块与层表一一对上 |
| `backend/alembic/HEAD` | 仓库自带 `check-migration-fork.py --rechain` 重接为单头 `b1a2c3d4e5f6` | 分支的 `a1c9f4e07b62` 改挂到 main 的头 |
| `backend/openapi.sha256` | 删 | main #4152 删了该文件与检查 |
| `backend/tests/contract/route_index.yaml` | 删 | main #4174 删了 `--check-annotations` 登记机制 |
| `test_legacy_error_ratchet.py`、`test_review_services_facade.py` | 删 | main #4174 删了这两个闸门测试 |
| `backend/uv.lock` | 取 main | 分支只把 pip 源换成清华镜像，无依赖变化 |
| `.github/workflows/deploy-scripts-test.yml`、`backend/scripts/seed_fusion_demo.py` | 取 main | 同一处改了同一句，按口径取 main（main 改成 `if repository:` 判据，比分支的 `forgejo_url` 更通用） |
| `backend/sandbox/skills/cheese/SKILL.md` | 取 main + 分支补的「机器独占才有写权限」一句 | 两件事，都要 |
| `docs/manual/dev/skills.md` | 取 main + 分支的 `skill-creator`/`mcp-builder` | 两件事，都要 |
| `docs/site/gen/prompt.py` | 取 main 的 `_Week` 结构 + 分支 `learning_goals`/`private_prompt` | 替身要跟合并后的 `Teaching` 一致 |

## 已知与本次合并无关的红
- `check-migration-safety` 的 2 条 error 在 main 上就有（`e7a4913c62bf`、`f4b1298ca631`），不是解冲突引入。
- `check_deferred_imports` 报的 `input_registration.py` / `personal_resources.py` 是 main 自己的文件，本次没碰；该检查不在 required CI。
- main 新开了 `RUF100`，分支那 8 处 `noqa` 压的是未启用规则，按仓库配置意图清掉。

## 需要负责人知道的取舍

- **项目集（category）级 teaching**：main 的 #4525 把「项目集」这一层整个删了（空间 + 题目两级），所以 `update_category` 不再接受 teaching。**default_role 留下**：它是 #944 的「项目集级默认队友」，和教学不是一件事，main 的模型列还在；这一轮把读路径和 PATCH 都补全了。题目级（`PublishTaskView` 的 DefaultTeammatePicker）那一路也在。

## 第二轮（核验报告补齐）

- **prepare 包**：分支的 `carried_skills` / `TurnContext.skill_bodies` / `carried_bodies` 接线按 main 的拆包重做到 `context.py` + `assembly.py` + `streaming.py`；`preparation/__init__.py` 重新导出 `carried_skills`。
- **`Teaching.fill`**：保留，只认 `{learning_goals}`（其余 token 随 #4525 删掉）。
- **`TRACKED_SECTIONS`**：教学**不**在里面 —— main 的 #8d772257 明确「一个会话保持开场那一份到下一次冷会话」，#4525 的注释也这么写；分支那条测试改成断言 main 的语义。分支的 `machine` 段被 main 并进了 `environment`。
- **多验收人**：`TaskSubmissionReviewRepository` 按分支版重做到 main 的新模块 `submission_repositories.py`（`reviewer_id`、`scalars().first()`、批量取最早一条）。
- **作废授权**：按分支口径收紧成「递卡人或布防人」（`_may_withdraw` + `voidFilerOnly`）；`voidForbidden` 是死键。
- **项目集默认队友**：`_category_to_api_model` 输出 `defaultRole`，`PatchSpaceCategoryRequest` / `update_category` / 路由接受它（整键语义）。
- **`MemberService.require_manager`**：按分支补回（含 `_team_admin` 与 `can_manage_project_members`），文案键 `projectManageForbidden` 补进前端 apiError/project.json。
- **PATCH 题目**：补回 `apply_task_default_role`；建题/改题/草稿发布的响应带 `include_private_teaching=True`。
- **发题页默认队友**：走「发布后按题目补写一次」（草稿字段里没有它），单测照新路径断言。
